import tkinter as tk
from tkinter import PhotoImage
from tkinter import messagebox

class OrderingMenuApp(tk.Tk):
    def __init__(self):
        tk.Tk.__init__(self)
        self.title("Ordering Menu")
        self.geometry("600x400")  # Set the initial size of the window

        # Create frames for different sections
        self.main_frame = tk.Frame(self)
        self.menu_frame = tk.Frame(self)
        self.dessert_frame = tk.Frame(self)
        self.location_frame = tk.Frame(self)
        self.specials_frame = tk.Frame(self)
        self.checkout_frame = tk.Frame(self)
        self.cart_frame = tk.Frame(self)

        self.create_buttons()
        self.create_labels()

        self.cart_items = []  # Track items added to the cart
        self.total = 0  # Initialize total amount
      
        # Initially show the main frame
        self.show_frame(self.main_frame)

    def create_buttons(self):
        # Create buttons on the main frame
        button1 = tk.Button(self.main_frame, text="Menu", command=lambda: self.show_frame(self.menu_frame))
        button1.pack(side=tk.LEFT, padx=5, pady=5)

        button2 = tk.Button(self.main_frame, text="Dessert of the Day", command=lambda: self.show_frame(self.dessert_frame))
        button2.pack(side=tk.LEFT, padx=5, pady=5)

        button3 = tk.Button(self.main_frame, text="Location", command=lambda: self.show_frame(self.location_frame))
        button3.pack(side=tk.LEFT, padx=5, pady=5)

        button4 = tk.Button(self.main_frame, text="Specials", command=lambda: self.show_frame(self.specials_frame))
        button4.pack(side=tk.LEFT, padx=5, pady=5)

        button5 = tk.Button(self.main_frame, text="Cart", command=lambda: self.show_frame(self.cart_frame))
        button5.pack(side=tk.LEFT, padx=5, pady=5)

        # Create "Home" button on other frames
        home_button = tk.Button(self.menu_frame, text="Home", command=lambda: self.show_frame(self.main_frame))
        home_button.pack(side=tk.BOTTOM, pady=10)

        home_button = tk.Button(self.dessert_frame, text="Home", command=lambda: self.show_frame(self.main_frame))
        home_button.pack(side=tk.BOTTOM, pady=10)

        home_button = tk.Button(self.location_frame, text="Home", command=lambda: self.show_frame(self.main_frame))
        home_button.pack(side=tk.BOTTOM, pady=10)

        home_button = tk.Button(self.specials_frame, text="Home", command=lambda: self.show_frame(self.main_frame))
        home_button.pack(side=tk.BOTTOM, pady=10)

        home_button = tk.Button(self.checkout_frame, text="Home", command=lambda: self.show_frame(self.main_frame))
        home_button.pack(side=tk.BOTTOM, pady=10)

        home_button = tk.Button(self.cart_frame, text="Home", command=lambda: self.show_frame(self.main_frame))
        home_button.pack(side=tk.BOTTOM, pady=10)

        # Menu items
        menu_items = [
            ("FriesBtn.png", "Fries", 3.99, 5),
            ("Pizza.png", "Slice of Pizza", 2.99, 10),
            ("BurgerBtn.png", "Burger", 4.99, 3)
        ]

        # Create "Add to Cart" button on menu items
        for item in menu_items:
            try:
                item_image = PhotoImage(file=item[0])  
                # Resize the image to fit smaller buttons
                item_image = item_image.subsample(3, 3)  
              # Adjust the subsample values for desired resize ratio
            except tk.TclError as e:
                print(f"Error loading image file: {item[0]}. {e}")
                continue

            # Create a frame for each item
            item_frame = tk.Frame(self.menu_frame)
            item_frame.pack(side=tk.LEFT, padx=20, pady=20)

            # Add image button with compound option
            item_button = tk.Button(item_frame, text=item[1], image=item_image, compound=tk.TOP, command=lambda item=item: self.add_to_cart(item))
            item_button.image = item_image
            item_button.pack()

            # Add label for item details
            item_label = tk.Label(item_frame, text=f"Price: ${item[2]}\nQuantity: {item[3]}", justify=tk.CENTER)
            item_label.pack()

        # Button to navigate to cart or checkout frame
        cart_button = tk.Button(self.menu_frame, text="Go to Cart", command=lambda: self.show_frame(self.cart_frame))
        cart_button.pack(side=tk.BOTTOM, pady=10)

        # Dessert item
        dessert_item = ("ChocoBar.png", "Chocolate Bar", 2.50, 3)  
  
        # Create a frame for the dessert item
        dessert_frame = tk.Frame(self.dessert_frame)
        dessert_frame.pack(side=tk.LEFT, padx=20, pady=20)
        try:
          dessert_image = tk.PhotoImage(file=dessert_item[0])
          dessert_image = dessert_image.subsample(3, 3)
        except tk.TclError as e:
          print(f"Error loading image file: {dessert_item[0]}. {e}")
        else:
          dessert_button = tk.Button(dessert_frame, text=dessert_item[1], image=dessert_image, compound=tk.TOP,
                                     command=lambda item=dessert_item: self.add_to_cart(item))
          dessert_button.image = dessert_image
          dessert_button.pack()

        # Add label for dessert details
        dessert_label = tk.Label(dessert_frame, text=f"Price: ${dessert_item[2]}", justify=tk.CENTER)
        dessert_label.pack()

        # Button to navigate to cart or checkout frame
        cart_button = tk.Button(self.dessert_frame, text="Go to Cart", command=lambda: self.show_frame(self.cart_frame))
        cart_button.pack(side=tk.BOTTOM, pady=10)
      
        # Location image
        location_image_path = "CBLocation.png"

        try:
          location_image = tk.PhotoImage(file=location_image_path)
          # Resize the image to fit inside the frame
          # Adjust the subsample values to resize the image
          location_image = location_image.subsample(2, 2)  # Example subsample values
        except tk.TclError as e:
          print(f"Error loading image file: {location_image_path}. {e}")
        else:
          location_label = tk.Label(self.location_frame, image=location_image)
          location_label.image = location_image
          location_label.pack()
          
       # Button to navigate to cart or checkout frame
        cart_button = tk.Button(self.location_frame, text="Go to Cart", command=lambda: self.show_frame(self.cart_frame))
        cart_button.pack(side=tk.BOTTOM, pady=10)

        # Specials items
        specials_items = [
            ("PizzaBtn.png", "Whole Pizza", 12.99, 2),
            ("Taco.png", "Tacos", 8.99, 4),
            ("ChickenSalad.png", "Salad with Chicken", 10.99, 1)
        ]

        for item in specials_items:
          try:
              item_image = PhotoImage(file=item[0])  # Create PhotoImage object for each item image
              # Resize the image to fit smaller buttons
              item_image = item_image.subsample(3, 3)  # Adjust the subsample values for desired resize ratio
          except tk.TclError as e:
              print(f"Error loading image file: {item[0]}. {e}")
              continue
          # Create a frame for each item
          item_frame = tk.Frame(self.specials_frame)
          item_frame.pack(side=tk.LEFT, padx=20, pady=20)

          # Add image button with compound option
          item_button = tk.Button(item_frame, text=item[1], image=item_image, compound=tk.TOP, command=lambda item=item: self.add_to_cart(item))
          item_button.image = item_image
          item_button.pack()

          # Add label for item details
          item_label = tk.Label(item_frame, text=f"Price: ${item[2]}\nQuantity: {item[3]}", justify=tk.CENTER)
          item_label.pack()

       # Button to navigate to cart frame
        cart_button = tk.Button(self.specials_frame, text="Go to Cart", command=lambda: self.show_frame(self.cart_frame))
        cart_button.pack(side=tk.BOTTOM, pady=10)
      
        # Create the Checkout button in the cart frame
        checkout_button = tk.Button(self.cart_frame, text="Checkout", command=self.checkout_order)
        checkout_button.pack(side=tk.TOP, pady=10)

    def show_cart(self):
      # Hide other frames and show the cart frame
      self.hide_frames()
      self.cart_frame.pack(fill=tk.BOTH, expand=True)
    def checkout_order(self):
      # Implement the functionality to checkout the order
      # Display a message indicating the order has been sent and will be ready in 10 minutes
      messagebox.showinfo("Order Sent!", "Order will be ready in 10 minutes. Thank you!")

    def hide_frames(self):
      # Hide all frames except the main frame
      self.main_frame.pack_forget()
      self.menu_frame.pack_forget()
      self.dessert_frame.pack_forget()
      self.location_frame.pack_forget()
      self.specials_frame.pack_forget()
      self.checkout_frame.pack_forget()
      self.cart_frame.pack_forget()

    def show_main(self):
      # Show the main frame
      self.show_frame(self.main_frame)
      
    def add_to_cart(self, item):
        # Placeholder function for adding items to cart
      self.cart_items.append(item)
      self.total += item[2]  # Update the total amount
      # Display the items and total in the cart frame
      for widget in self.cart_frame.winfo_children():
          widget.destroy()

      for cart_item in self.cart_items:
          item_label = tk.Label(self.cart_frame, text=f"{cart_item[1]} - ${cart_item[2]}")
          item_label.pack()

      total_label = tk.Label(self.cart_frame, text=f"Total: ${self.total}")
      total_label.pack()

      home_button = tk.Button(self.cart_frame, text="Home", command=lambda: self.show_frame(self.main_frame))
      home_button.pack(side=tk.BOTTOM, pady=10)
      
      # Create the Checkout button in the cart frame
      checkout_button = tk.Button(self.cart_frame, text="Checkout", command=self.checkout_order)
      checkout_button.pack(side=tk.TOP, pady=10)
      
        
    def create_labels(self):
        # Create label for order preparation time
        order_label = tk.Label(self, text="Orders will take 10 minutes to be prepared.")
        order_label.pack(side=tk.BOTTOM, pady=10)

    def show_frame(self, frame):
        # Hide all frames and show the requested frame
        self.main_frame.pack_forget()
        self.menu_frame.pack_forget()
        self.dessert_frame.pack_forget()
        self.location_frame.pack_forget()
        self.specials_frame.pack_forget()
        self.checkout_frame.pack_forget()
        self.cart_frame.pack_forget()

        frame.pack(fill=tk.BOTH, expand=True)

if __name__ == "__main__":
    app = OrderingMenuApp()
    app.mainloop()
